<?php
/**
 * Open Source Social Network
 * @link      https://www.opensource-socialnetwork.org/
 * @package   Intro
 * @author    Allon Prooit <AT3META@3NCIRCLE.COM>
 * @copyright (C) Allon Prooit
 * @license   GNU General Public License https://www.gnu.de/documents/gpl-3.0.en.html
 */

ossn_register_languages('en', array(
	'intro' => 'Intro',
	'com:intro:label' => 'Intro',
	'com:intro:pagetitle' => 'Intro',
	'com:intro:placeholder' => 'Feel free to add an introduction here ...',
	'com:intro:search:result' => "found %s intros containing '%s'",
	'com:intro:search:result:total' => 'found total number of %s intros',
	'com:intro:search:noresult' => "no intros found containing '%s'",
	'com:intro:visibility' => 'Privacy',
	'com:intro:accessibility:option:2' => 'Public',
	'com:intro:accessibility:option:3' => 'Friends Only',
));
