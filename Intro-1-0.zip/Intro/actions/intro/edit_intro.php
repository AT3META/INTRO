<?php
/**
 * Open Source Social Network
 * @link      https://www.opensource-socialnetwork.org/
 * @package   intro
 * @author    Allon Prooit <AT3META@3NCIRCLE.COM>
 * @copyright (C) 3NCIRCLE.COM
 * @license   GNU General Public License https://www.gnu.de/documents/gpl-3.0.en.html
 */
 
$user_get = ossn_user_by_username(input('username'));
if ((!$user_get) || ($user_get && $user_get->guid !== ossn_loggedin_user()->guid)) {
	redirect("home");
}
$user_get->data = new stdClass;
$guid = $user_get->guid;
if (!empty($guid)) {
	$user_get->data->intro = input('intro');
	$user_get->data->intro_access = input('intro_access');
	$user_get->save();
	ossn_trigger_message(ossn_print('user:updated'), 'success');
}
redirect(REF);
