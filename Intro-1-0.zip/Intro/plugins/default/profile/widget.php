<?php
/**
 * Open Source Social Network
 * @link      https://www.opensource-socialnetwork.org/
 * @package   Intro
 * @author    Allon Prooit
 * @copyright (C) 3NCIRCLE.COM
 * @license   GNU General Public License https://www.gnu.de/documents/gpl-3.0.en.html
 */
?>
<script> 
$(document).ready(function() { 
    var code = '<div class="ossn-widget"><div class="widget-heading">'
    + Ossn.Print('intro') + '</div><div class="widget-contents intro-profile-widget">'
    + '<?php if (isset($params['user']->intro)) { echo $params['user']->intro; } else { echo 'none'; } ?>'
    + '</div>'; 
    $('.ossn-profile-sidebar .ossn-profile-modules').prepend(code);
});
</script>