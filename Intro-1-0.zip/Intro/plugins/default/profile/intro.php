<?php
/**
 * Open Source Social Network
 * @link      https://www.opensource-socialnetwork.org/
 * @package   Intro
 * @author    Allon Prooit
 * @copyright (C) 3NCIRCLE.COM
 * @license   GNU General Public License https://www.gnu.de/documents/gpl-2.0.en.html
 */
 
if ($params['user']->intro) {
	 echo $params['user']->intro;
}
?>

