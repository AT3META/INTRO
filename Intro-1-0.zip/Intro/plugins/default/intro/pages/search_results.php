<?php
/**
 * Open Source Social Network
 * @link      https://www.opensource-socialnetwork.org/
 * @package   Intro
 * @author    Allon Prooit
 * @copyright (C) 3NCIRCLE.COM
 * @license   GNU General Public License https://www.gnu.de/documents/gpl-3.0.en.html
 */
?>
<div class="ossn-widget">
	<div class="widget-heading">
		<i class="fa fa-eye"></i> <?php echo $params['page_header']; ?>
	</div>
	<div class="widget-contents">
		<?php
			$intros = $params['intros'];
			if ($intros) {
				foreach ($intros as $item) {
					echo ossn_plugin_view('intro/list/all_intros_item', array('item' => $item));	
				}
			}
		?>
	</div>
</div>