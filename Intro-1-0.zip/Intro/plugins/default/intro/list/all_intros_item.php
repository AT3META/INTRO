<?php
/**
 * Open Source Social Network
 * @link      https://www.opensource-socialnetwork.org/
 * @package   Intro
 * @author    Allon Prooit
 * @copyright (C) 3NCIRCLE.COM
 * @license   GNU General Public License https://www.gnu.de/documents/gpl-3.0.en.html
 */

$fullname = $params['item']->first_name . ' ' . $params['item']->last_name;
if (com_is_active('DisplayUsername')) {
	$fullname = $params['item']->username;
}
?>
<div class="row">
	<div class="col-md-12">
		<a href="<?php echo 'u/' . $params['item']->username . '/intro';?>"><?php echo $fullname;?></a>
	</div>
</div>