/**
 * Open Source Social Network
 * @link      https://www.opensource-socialnetwork.org/
 * @package   Intro
 * @author    Allon Prooit
 * @copyright (C) Allon Prooit
 * @license   GNU General Public License https://www.gnu.de/documents/gpl-3.0.en.html
 */

.ossn-menu-search-com-intro-search-intro .text::before {
	font-family: 'Font Awesome 5 Free';
	content: "\f06e";
	font-weight: 900;
	padding-right: 10px;
	vertical-align: middle;
	float: left;
}
