<?php
/**
 * Open Source Social Network
 * @link      https://www.opensource-socialnetwork.org/
 * @package   Intro
 * @author    Allon Prooit
 * @copyright (C) 3NCIRCLE.COM
 * @license   GNU General Public License https://www.gnu.de/documents/gpl-3.0.en.html
 */
 
$user = ossn_loggedin_user();
$params['intro'] = (isset($user->intro) ? $user->intro : '');
$params['intro_access'] = (isset($user->intro_access) ? $user->intro_access : OSSN_PUBLIC);
$params['username'] = $user->username;
echo ossn_view_form('account_settings/intro', array(
	'action' => ossn_site_url() . 'action/intro/edit_intro',
	'component' => 'intro',
	'params' => $params	
), false);